package parcial.vallina;

public class NaveExploracion extends Nave implements Exploradores{
    
    private TipoMision tipo;

    public NaveExploracion(TipoMision tipo, String nombre, int capacidad, String añoLanzamiento) {
        super(nombre, capacidad, añoLanzamiento);
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return super.toString() + "NaveExploracion{" + "tipo=" + tipo + '}';
    }
    
    @Override
    public void explorar(){
        System.out.print("La nave de exploracion " + getNombre() + " inicia una"
                + " mision de " + tipo);
    }
    
    
    
    
}
