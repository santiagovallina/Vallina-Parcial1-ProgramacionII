package parcial.vallina;

public class NaveRepetidaException extends RuntimeException{
    
    private static final String MESSAGE = "Esta nave ya es parte de la agencia.";
    
    public void NaveRepetidaException(){
        System.out.println(MESSAGE);
    }
    
}
