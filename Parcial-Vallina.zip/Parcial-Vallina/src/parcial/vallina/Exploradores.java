package parcial.vallina;

public interface Exploradores {
    void explorar();
}
