package parcial.vallina;

public class CargaInvalidaException extends RuntimeException{
    private static final String MESSAGE = "La carga debe ser mayor a 100"
            + " y menor a 500 toneladas";
    
    public void CargaInvalidaException(){
        System.out.println(MESSAGE);
    }
}
