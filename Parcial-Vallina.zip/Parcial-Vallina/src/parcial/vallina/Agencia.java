package parcial.vallina;

import java.util.ArrayList;

public class Agencia {
    
    private ArrayList<Nave> naves;

    public Agencia() {
        naves = new ArrayList<>();
    }
    
    
    
    public void agregaNave(Nave nave){
        if(nave == null){
            throw new NullPointerException("Pasaron un null.");
        }
        else if(naves.contains(nave)){
            throw new NaveRepetidaException();
        }
        naves.add(nave);
    }
    
    
    public void mostrarNaves(){
        for(Nave nave : naves){
            System.out.println(nave);
        }
    }
    
    public void iniciarExploracion(){
        for(Nave nave : naves){
            if(nave instanceof CruceroEstelar){
               System.out.println(nave.getNombre() + " solo transporta pasajeros."); 
            }
            else{
                nave.explorar();
                System.out.println();
            }
        }
    }
}
