package parcial.vallina;

public class CruceroEstelar extends Nave{
    
    private int cantidadPasajeros;

    public CruceroEstelar(int cantidadPasajeros, String nombre, int capacidad, String añoLanzamiento) {
        super(nombre, capacidad, añoLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public String toString() {
        return super.toString() + "CruceroEstelar{" + "cantidadPasajeros=" + cantidadPasajeros + '}';
    }

    
    
    
    
}
