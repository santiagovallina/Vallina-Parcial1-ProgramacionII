package parcial.vallina;

public class Carguero extends Nave implements Exploradores{
    
    private static final int MIN_CARGA = 100;
    private static final int MAX_CARGA = 500;
    
    private int carga;

    public Carguero(int carga, String nombre, int capacidad, String añoLanzamiento) {
        super(nombre, capacidad, añoLanzamiento);
        this.carga = carga;
    }

    public void setCarga(int carga) {
        if(carga < MIN_CARGA || carga > MAX_CARGA){
            throw new CargaInvalidaException();
        }
    }
    
    @Override
    public void explorar(){
        System.out.print("El carguero " + getNombre() + " sale con las cargas.");
    }
    
    
    @Override
    public String toString() {
        return super.toString() + "Carguero{" + "carga=" + carga + '}';
    }

    
    
    
    
}
