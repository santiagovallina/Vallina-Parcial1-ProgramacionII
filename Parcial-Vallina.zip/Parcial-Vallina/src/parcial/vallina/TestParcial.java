package parcial.vallina;

public class TestParcial {

    public static void main(String[] args) {
        
        Agencia ag = new Agencia();
        
        Carguero carguero = new Carguero(500, "cargatuti", 100, "2022");
    Carguero carguero2 = new Carguero(250, "pesado", 150, "2020");
        
        NaveExploracion explo = new NaveExploracion(TipoMision.CARTOGRAFIA, "colon", 50, "2022");
        NaveExploracion explo2 = new NaveExploracion(TipoMision.INVESTIGACION, "raganar", 200, "2019");
        
        CruceroEstelar cruce = new CruceroEstelar(266, "titanic espacial", 266, "2022");
        CruceroEstelar cruce2 = new CruceroEstelar(300, "msc", 300, "2015");
        
        try{
            ag.agregaNave(carguero);
            ag.agregaNave(carguero2);
            ag.agregaNave(explo);
            ag.agregaNave(explo2);
            ag.agregaNave(cruce);
            ag.agregaNave(cruce2); 
        }
        catch(NullPointerException ex){
            System.out.println(ex.getMessage());
        }
        catch(NaveRepetidaException ex){
            System.out.println(ex.getMessage());
        }
        catch(RuntimeException ex){
            System.out.println(ex.getMessage());
        }
        
        
        ag.mostrarNaves();
        System.out.println("---------------");
        ag.iniciarExploracion();
        
        
        
    }
    
}
