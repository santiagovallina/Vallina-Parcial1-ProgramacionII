package parcial.vallina;

public abstract class Nave {
    
    private String nombre;
    private int capacidad;
    private String añoLanzamiento;

    public Nave(String nombre, int capacidad, String añoLanzamiento) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.añoLanzamiento = añoLanzamiento;
    }
    
    
    public void explorar(){};

    
    @Override
    public String toString() {
        return "Nave{" + "nombre=" + nombre + ", capacidad=" + 
                capacidad + ", anioLanzamiento=" + añoLanzamiento + '}';
    }

    public String getNombre() {
        return nombre;
    }

    
    
    
    
    
}
