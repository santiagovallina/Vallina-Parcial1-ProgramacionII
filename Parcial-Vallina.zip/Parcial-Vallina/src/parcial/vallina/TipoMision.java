package parcial.vallina;

public enum TipoMision {
    
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO;
    
}
